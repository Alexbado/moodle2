<?php
$file = $DB->get_record ( 'jcode_files', array (
		'user_id' => $USER->id,
		'jcode_id' => $jcode->id 
) );
// verifica se o arquivo ainda nao foi enviado
if (empty ( $file )) {
	require_once 'submission_form.php';
	$form = new mod_submission_form ( array (
			"course" => $course->id,
			"jcode" => $id 
	) );
	
	if ($data = $form->get_data ()) {
		// manipulando arquivo
		$filename = $form->get_new_filename ( 'userfile' );
		// criando pastas necessarias para arquivamento
		if (! is_dir ( $CFG->dataroot . '/mod' )) {
			mkdir ( $CFG->dataroot . '/mod' );
			mkdir ( $CFG->dataroot . '/mod/jcode' );
		}
		// cria o diretorio que representa o curso no Moodledata
		if (! is_dir ( $CFG->dataroot . '/mod/jcode/' . $COURSE->id )) {
			mkdir ( $CFG->dataroot . '/mod/jcode/' . $COURSE->id );
		}
		// cria o diretorio que representa a atividade no Moodledata
		if (! is_dir ( $CFG->dataroot . '/mod/jcode/' . $COURSE->id . "/" . $jcode->id )) {
			mkdir ( $CFG->dataroot . '/mod/jcode/' . $COURSE->id . "/" . $jcode->id );
		}
		
		// cria o diretorio que representa o usuário no Moodledata
		if (! is_dir ( $CFG->dataroot . '/mod/jcode/' . $COURSE->id . "/" . $jcode->id . "/" . $USER->id )) {
			mkdir ( $CFG->dataroot . '/mod/jcode/' . $COURSE->id . "/" . $jcode->id . "/" . $USER->id );
		}
		
		// local onde o arquivo será gravado
		$save_path = $CFG->dataroot . '/mod/jcode/' . $COURSE->id . "/" . $jcode->id . "/" . $USER->id . '/';
		// movendo o arquivo
		$success = $form->save_file ( 'userfile', $save_path . $filename, true );
		
		// compilando
		system ( "javac $save_path$filename", $resultado );
		if ($resultado == "1") {
			echo "Erro ao compilar arquivo";
		}
		
		$file_info = pathinfo ( $filename );
		// esecutando o arquivo
		exec ( "cd $save_path; java {$file_info['filename']} -cp 2>&1", $out, $success );
		$out = serialize ( $out );
		
		// salvando registro
		if ($success == 0) {
			$post_file = new stdClass ();
			$post_file->jcode_id = $jcode->id;
			$post_file->filename = $filename;
			$post_file->user_id = $USER->id;
			$post_file->submit_date = time ();
			$post_file->grade = 0;
			$post_file->result = $out;
			
			$DB->insert_record ( 'jcode_files', $post_file );
		}
		
		$url = $CFG->wwwroot . "/mod/jcode/view.php?id=" . $id;
		redirect ( $url, "Processando arquivo, aguarde por favor..." );
	} else {
		$form->display ();
	}
} else {
	$o = $OUTPUT->box_start ( 'boxaligncenter submissionsummarytable' );
	$t = new html_table ();
	$o .= "Atividade Postada: " . $file->filename;
	$o .= " - Remover";
	jcode_add_table_row_tuple($t, get_string('timeavaliable', 'jcode'), userdate($jcode->timeavaliable));
	jcode_add_table_row_tuple($t, get_string('timedue', 'jcode'),userdate($jcode->timedue));
	//jcode_add_table_row_tuple($t, get_string('submit_date', 'jcode'),userdate($jcode->submit_date));

	
	$o .= $OUTPUT->box_end();
	echo html_writer::table($t);
	echo $o;
}



